# INSTRUÇÕES — Trabalho Semestral POO 2026/01 (Exercício 2)

**NÃO comite esta pasta (`_documentos-para-voce/`) no repositório.** Ela é só para você.

---

## 1. Pré-requisitos

- **JDK 25** (Temurin/Adoptium ou o que a IntelliJ baixar para você: File → Project Structure → SDK → Download JDK → 25).
- **Maven 3.9+** (a IntelliJ já embute; para linha de comando, instale o Maven ou use o wrapper da IDE).
- **Docker Desktop** (opcional, só para a TUS-2381).
- Se você só tiver **JDK 21**: abra o `pom.xml` e troque `<maven.compiler.release>25</maven.compiler.release>` para `21`. Todo o código compila em 21. Mas o ideal é usar 25, porque o enunciado e o CI usam Java 25.

## 2. Montando o seu fork

1. Faça o fork de `pagliares/academic-system-semester-assignment-2026` no GitHub (se ainda não fez).
2. Clone o fork na sua máquina.
3. Copie o conteúdo deste zip **para a raiz do fork**, substituindo o que existir:
   - a pasta `academic-system/` (substitui a do starter — pode apagar a antiga antes);
   - a pasta `.github/` (fica na **raiz do repositório**, não dentro de `academic-system/`).
4. Não mexa no `README.md` do professor — ele já documenta as histórias, o Docker e a branch protection (isso atende a TUS-2381 e a TUS-2420 AC10).

## 3. Build e execução (PRIMEIRA COISA A FAZER)

```bash
cd academic-system
mvn clean verify        # compila + roda os 13 arquivos de teste + gera cobertura JaCoCo
```

⚠️ **Eu não consegui compilar o projeto no meu ambiente** (sem acesso ao Maven Central aqui). A sintaxe de todos os arquivos foi verificada com javac, mas o primeiro `mvn clean verify` é seu. **Se aparecer qualquer erro, me mande a saída completa que eu corrijo na hora.**

Rodando a aplicação:

```bash
mvn exec:java                                      # versão linha de comando
mvn javafx:run                                     # versão gráfica JavaFX
mvn clean package                                  # gera o jar
java -jar target/AcademicSystem-1.0-SNAPSHOT.jar   # roda o jar (CLI)
```

**Credenciais** (arquivo `src/main/resources/users.txt`):

| Usuário | Senha | Papel |
|---|---|---|
| admin | admin123 | ADMIN |
| professor | prof123 | PROFESSOR |

Arquivos gerados em tempo de execução: `data/academic-data.{txt,xml,json}` (persistência), `logs/academic-system.log` e `logs/audit.log` (auditoria). Ambas as pastas estão no `.gitignore`.

## 4. Docker (TUS-2381)

```bash
cd academic-system
docker build -t academic-system .
docker run -it academic-system     # -it é obrigatório: a CLI é interativa
```

Se a imagem `maven:3.9-eclipse-temurin-25` não existir no seu Docker, troque a primeira linha do Dockerfile por `maven:3-eclipse-temurin-25` ou, em último caso, `maven:3.9-eclipse-temurin-21` (e ajuste o release no pom para 21 nesse cenário).

## 5. GitHub: o que só você pode fazer

1. **Commits**: o ideal é não subir tudo em um commit só. Sugestão de blocos (na ordem): modelo de domínio → exceções → validação → segurança → repositórios → services → controller → views CLI → Main → telas JavaFX → testes → Docker → workflows. Ex.: `git add src/main/java/**/model` → `git commit -m "US-2361/TUS-2365: modelo de dominio com Lombok"`.
2. **Push** para um branch (ex.: `develop`) e abra um **Pull Request** para `main` — os workflows CI e PR Validation vão rodar sozinhos.
3. **Branch protection (TUS-2420, feito na interface do GitHub)**: Settings → Branches → Add branch ruleset (ou Add rule) para `main` → marque **Require a pull request before merging** e **Require status checks to pass before merging** → selecione os checks `build-and-test` (CI) e `validate` (PR Validation). Pronto: push direto na main fica bloqueado.
4. **Imagem Docker (TUS-2417)**: publica automaticamente no GitHub Container Registry usando o `GITHUB_TOKEN` — **nenhum secret manual é necessário**. Após o merge na main, veja em: seu perfil → Packages → `academic-system`. (Se seu username tiver letra maiúscula, o GHCR exige minúsculas — me avise que eu ajusto o workflow.)
5. **Release (TUS-2419)**:
   ```bash
   git tag v1.0.0
   git push --tags
   ```
   O workflow cria a release no GitHub com o jar anexado.
6. Se os workflows não dispararem: aba **Actions** do fork → botão para habilitar workflows (o GitHub desabilita Actions em forks por padrão).

## 6. Troubleshooting de versões

| Sintoma | Correção |
|---|---|
| JaCoCo reclama de "Unsupported class file major version 69" | Suba `<jacoco.version>` para `0.8.14` (ou a mais recente) |
| Mockito/ByteBuddy reclama de class file version | Suba `<mockito.version>` para a última 5.x |
| Lombok não gera getters na IntelliJ | Instale o plugin Lombok e habilite Annotation Processing (Settings → Build → Compiler → Annotation Processors) |
| `mvn javafx:run` falha com erro de módulo | Rode pela raiz `academic-system/`, nunca pela raiz do repositório |

## 7. Próxima etapa

O **Exercício 3** (migração para uma segunda linguagem OO — faremos em **C#**) fica para depois que você validar o build Java. Me mande um "build ok" (ou os erros) e eu gero a versão C# em cima desta mesma arquitetura.
