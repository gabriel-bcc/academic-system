# GUIA DE DEFESA — Apresentação 29/06, Lab B-207

A nota é 0,3 código + 0,3 apresentação + **0,4 perguntas**. Este guia existe para esses 0,7. Leia com o projeto aberto na IDE, rodando cada coisa que ler. Não decore: entenda o *porquê* de cada decisão — é isso que o Pagliares pergunta.

---

## 1. Mapa: bloco de histórias → conceito de POO → onde está no código

| Bloco | Conceito | Arquivo(s)-chave | O que dizer em 1 frase |
|---|---|---|---|
| US-0000 | **Singleton** | `AcademicSystem` | Construtor privado + instância única `static final` criada de forma *eager* — thread-safe sem `synchronized`. `getInstance()` é o único ponto de acesso. |
| US-2361, TUS-2365 | **Herança, polimorfismo, abstração, Lombok** | `Assessment` (abstrata) + `Exam`, `PracticalAssignment`, `Seminar`, `Assignment` | Atributos comuns (descrição, valor, peso) na superclasse; cada subclasse responde `getType()` polimorficamente. Lombok gera getters/setters/equals/hashCode/toString via annotation processing em tempo de compilação. |
| TUS-2382/2384 | **Identidade e igualdade** | `Identifiable`, `AcademicClass`, `User` | equals/hashCode só pelo identificador (`code`/`username`), via `@EqualsAndHashCode(onlyExplicitlyIncluded=true)`. Campos mutáveis (título) fora do hash → objeto não "some" do `HashSet` se o título mudar. |
| TUS-2362, US-2372/73/74 | **Repository + Strategy** | `ClassRepository` + `TxtClassRepository`, `XmlClassRepository`, `JsonClassRepository`, `PersistenceService` | A interface é a abstração (Repository); cada formato é uma estratégia intercambiável. O `PersistenceService` guarda a estratégia ativa num `EnumMap` e o domínio nunca sabe em que formato é salvo (OCP: formato novo = classe nova, sem alterar as existentes). |
| US-2366/69/78/79/80 | **Autenticação, RBAC, sessão** | `AuthenticationService`, `AuthorizationService`, `Session`, `SystemOperation` | Login valida credenciais vindas do repositório TXT e cria uma `Session`; cada operação protegida passa por `authorize(session, operação)`, que consulta a matriz `PERMISSIONS`. O menu dinâmico usa **a mesma matriz** (`isAllowed`) — menu esconde, autorização bloqueia. |
| US-2367/68/69 | **Hierarquias de exceção** | pacote `exception` | Três famílias separadas: `AcademicSystemException` (domínio), `KeyboardInputException` (entrada), `AcademicSecurityException` (segurança). O `Main` tem um `catch` para cada ramo — mensagens claras, app nunca morre inesperadamente. |
| TUS-2371/2385 | **Jakarta Bean Validation** | anotações no `model` + `DomainValidator` | Regras declaradas no próprio modelo (`@NotBlank`, `@Positive`, `@DecimalMax`); o `DomainValidator` centraliza a checagem e converte violações em `DomainValidationException` (que É uma exceção de domínio — herança de novo). |
| TUS-2370/96/97/98/99/2400 | **GRASP Controller, camadas, coesão** | `AcademicSystemController` + 4 services | Controller só faz duas coisas: autoriza e delega. Cada service tem uma responsabilidade (alta coesão); controller não conhece detalhes de persistência nem de relatório (baixo acoplamento). |
| US-2375/76/77 | **Separação lógica × apresentação** | pacote `report` + `ReportService` | Geradores montam o texto a partir do domínio (somente leitura); o service audita com o papel do solicitante e devolve `String` — CLI imprime, JavaFX põe num `TextArea`. Mesma lógica, duas apresentações. |
| TUS-2390–94 | **Logging e auditoria** | `logback.xml` + logger `AUDIT` | SLF4J é a fachada, Logback a implementação (trocável). Logger nomeado `AUDIT` com appender próprio (`logs/audit.log`) registra login/logout, negações de acesso, persistências e relatórios. Senha nunca é logada. |
| TUS-2383–2405 | **JUnit 5 + Mockito** | pacote de testes | Testes de estado (igualdade, validação, services) e de **interação** com Mockito: no teste do controller, os services são mocks e `verify()` prova a delegação; o `AuthorizationService` é real para provar que a regra de acesso é preservada. |
| TUS-2406–14 | **JavaFX + MVC** | `JavaFXMain` + `view/gui` | Telas construídas programaticamente (cada tela é uma classe que devolve um `Parent`). A GUI reusa os MESMOS services/controllers da CLI; `JavaFXMain` autentica via `AuthenticationController` (TUS-2414) e não conhece o `AuthenticationService`. |
| TUS-2381, 2415–20 | **Docker + CI/CD** | `Dockerfile`, `.github/workflows/` | Build multi-stage (Maven compila e TESTA dentro da imagem; runtime só com JRE). 4 workflows: CI (push/PR + artefato JaCoCo), validação de PR, publicação da imagem no GHCR versionada por sha/tag, e release por tag com o jar. Branch protection na main exige PR + checks verdes. |

## 2. Perguntas prováveis do Pagliares (com a resposta)

**"Por que Singleton no AcademicSystem? E por que eager?"**
Porque o sistema precisa de um único ponto de verdade para o estado acadêmico, acessível pela CLI e pela GUI. Eager (campo `static final`) porque a JVM garante inicialização thread-safe no carregamento da classe — mais simples que lazy com `synchronized` ou double-checked locking. Custo: a instância existe mesmo sem uso, irrelevante aqui. O `reset()` existe para os testes limparem o estado compartilhado.

**"Por que a turma se chama AcademicClass e não Class?"**
`Class` colide com `java.lang.Class`, que é importada implicitamente em todo arquivo Java — geraria ambiguidade e código confuso. Mesmo motivo de `AcademicSecurityException` (evita `java.lang.SecurityException`) e `AcademicClassNotFoundException` (evita `java.lang.ClassNotFoundException`).

**"Por que o ADMIN não pode cadastrar avaliação?"**
Segui literalmente a matriz do README do professor: ADMIN = turmas, persistência e relatórios administrativos; PROFESSOR = avaliações e relatórios acadêmicos. Isso deixa a US-2361 AC8 testável ("usuário sem privilégio é negado") e demonstra que RBAC restringe até o administrador fora da sua alçada. A matriz está num único lugar (`AuthorizationService.PERMISSIONS`), então mudar a regra é mudar uma linha.

**"Suas exceções estendem RuntimeException. Por quê?"**
Exceções *checked* obrigariam `throws` em toda a cadeia view→controller→service, poluindo assinaturas para erros que são tratados num único lugar (o loop do `Main` e os handlers das telas). Unchecked mantém as camadas limpas e o tratamento centralizado — abordagem padrão em frameworks modernos (Spring faz o mesmo).

**"Como o XML é gerado sem JAXB?"**
Com a API DOM da própria plataforma (`DocumentBuilderFactory` + `Transformer`): zero dependência externa e o domínio fica livre de anotações de serialização. No JSON, mesma filosofia: o Jackson serializa `LinkedHashMap`s montados no repositório, não o modelo — os ACs exigem que a persistência não modifique o modelo de domínio.

**"O que o Lombok faz exatamente? Tem custo em runtime?"**
É um annotation processor: durante a compilação, manipula a AST e injeta os métodos no bytecode. Em runtime o Lombok nem precisa estar no classpath (escopo `provided`). `@EqualsAndHashCode(onlyExplicitlyIncluded = true)` + `@Include` no `code` implementam exatamente o contrato da TUS-2382.

**"O menu esconder a opção já não basta como segurança?"**
Não — interface é conveniência, não segurança (US-2378 AC6). Se alguém chamar o controller direto (outra view, um teste, código malicioso), o `authorize()` bloqueia e audita. O teste `preservesAuthorizationRulesForClassRegistration` prova isso: PROFESSOR chamando `registerClass` toma `AuthorizationException` e o mock do service comprova **zero interações**.

**"Pra que ParameterMessageInterpolator no DomainValidator?"**
O Hibernate Validator, por padrão, exige uma implementação de Expression Language para interpolar mensagens. Como minhas mensagens são literais (sem `${...}`), o `ParameterMessageInterpolator` elimina essa dependência inteira — menos jar, mesmo resultado.

**"Onde entra Mockito de verdade, e não só JUnit?"**
Dois lugares: `AuthenticationServiceTest` mocka o `UserRepository` (testo autenticação sem arquivo no disco) e `AcademicSystemControllerTest` mocka os 4 services para testar **comportamento**: `verify(classService).registerClass(...)` prova a delegação com os argumentos exatos; `verifyNoInteractions` prova que a negação de acesso acontece ANTES de tocar no service.

**"E o que ficou de fora?"** (responder com segurança, sem se desculpar)
Carregar dados persistidos de volta (os ACs só pedem salvar), senha com hash, e gestão de usuários — todos listados como *Future Improvements* no próprio README do professor. Eu citaria BCrypt para hash e um `load()` na interface `ClassRepository` como evolução natural.

## 3. Roteiro de demonstração (~8 min)

1. `mvn clean verify` já rodado antes — mostre o BUILD SUCCESS e os testes verdes; abra `target/site/jacoco/index.html` (cobertura, TUS-2416).
2. `mvn exec:java` → login `admin/admin123` → cadastre a turma `CC101 / Orientacao a Objetos` → tente cadastrar avaliação (não aparece no menu de ADMIN — explique o RBAC) → configure persistência para XML → salve → **abra `data/academic-data.xml` e `logs/audit.log`** no editor (auditoria com papel e operação).
3. Logout (sem fechar o app — US-2379) → login `professor/prof123` → note o menu diferente e renumerado (US-2380) → cadastre `Prova 1, valor 10, peso 0.4` e `Seminario, 10, 0.6` → relatório de pesos (COMPOSICAO VALIDA = 1.00) → tente digitar letra onde pede número (exceção de teclado tratada, app continua).
4. Encerre, rode `mvn javafx:run` → mesmo fluxo na GUI: login errado (mensagem em vermelho), tela baseada em papel, visualização em árvore.
5. No navegador: aba Actions do fork (workflows verdes), um PR antigo mostrando os checks obrigatórios, Packages com a imagem no GHCR e a Release v1.0.0 com o jar.
6. Fechamento: "a arquitetura em camadas permitiu adicionar a GUI inteira sem tocar em uma linha de regra de negócio — é o mesmo controller e os mesmos services da CLI."

## 4. Antes do dia 29

- Rode o roteiro inteiro pelo menos duas vezes sozinho, cronometrando.
- Para cada arquivo do mapa da seção 1, abra e leia — se algum trecho parecer mágico, me pergunte antes da apresentação.
- Deixe `data/` e `logs/` apagados antes de demonstrar (nascem limpos na hora, mais convincente).
